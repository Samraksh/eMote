//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_native.h"
#include "spot_hardware_native_Microsoft_SPOT_Hardware_I2CDevice.h"

using namespace Microsoft::SPOT::Hardware;

INT32 I2CDevice::Execute( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void I2CDevice::Initialize( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

