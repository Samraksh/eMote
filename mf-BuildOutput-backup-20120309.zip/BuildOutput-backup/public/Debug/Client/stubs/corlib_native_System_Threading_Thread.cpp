//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Threading_Thread.h"

using namespace System::Threading;

void Thread::_ctor( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, HRESULT &hr )
{
}

void Thread::Start( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void Thread::Abort( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void Thread::Suspend( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void Thread::Resume( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

INT32 Thread::get_Priority( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void Thread::set_Priority( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
}

INT8 Thread::get_IsAlive( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

void Thread::Join( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

INT8 Thread::Join( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 Thread::Join( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT32 Thread::get_ThreadState( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void Thread::Sleep( INT32 param0, HRESULT &hr )
{
}

UNSUPPORTED_TYPE Thread::get_CurrentThread( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Thread::GetDomain( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

