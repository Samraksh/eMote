//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_usb_native.h"
#include "spot_hardware_usb_native_Microsoft_SPOT_Hardware_UsbClient_UsbStream.h"

using namespace Microsoft::SPOT::Hardware::UsbClient;

INT32 UsbStream::nativeOpen( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void UsbStream::nativeClose( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

INT32 UsbStream::nativeRead( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 UsbStream::nativeWrite( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void UsbStream::nativeFlush( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

