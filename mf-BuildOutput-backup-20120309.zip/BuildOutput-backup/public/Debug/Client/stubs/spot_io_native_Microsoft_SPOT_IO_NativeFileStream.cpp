//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_io_native.h"
#include "spot_io_native_Microsoft_SPOT_IO_NativeFileStream.h"

using namespace Microsoft::SPOT::IO;

void NativeFileStream::_ctor( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, INT32 param1, HRESULT &hr )
{
}

INT32 NativeFileStream::Read( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, INT32 param3, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 NativeFileStream::Write( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, INT32 param3, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT64 NativeFileStream::Seek( CLR_RT_HeapBlock* pMngObj, INT64 param0, UINT32 param1, HRESULT &hr )
{
    INT64 retVal = 0; 
    return retVal;
}

void NativeFileStream::Flush( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

INT64 NativeFileStream::GetLength( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT64 retVal = 0; 
    return retVal;
}

void NativeFileStream::SetLength( CLR_RT_HeapBlock* pMngObj, INT64 param0, HRESULT &hr )
{
}

void NativeFileStream::GetStreamProperties( CLR_RT_HeapBlock* pMngObj, INT8 * param0, INT8 * param1, INT8 * param2, HRESULT &hr )
{
}

void NativeFileStream::Close( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

