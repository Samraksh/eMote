//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_native.h"
#include "spot_hardware_native_Microsoft_SPOT_Hardware_Cpu.h"

using namespace Microsoft::SPOT::Hardware;

UINT32 Cpu::get_SystemClock( HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

UINT32 Cpu::get_SlowClock( HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Cpu::get_GlitchFilterTime( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void Cpu::set_GlitchFilterTime( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
}

