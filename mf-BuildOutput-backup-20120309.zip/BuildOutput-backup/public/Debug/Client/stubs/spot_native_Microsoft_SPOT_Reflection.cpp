//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Microsoft_SPOT_Reflection.h"

using namespace Microsoft::SPOT;

UNSUPPORTED_TYPE Reflection::GetTypesImplementingInterface( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

INT8 Reflection::IsTypeLoaded( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

UINT32 Reflection::GetTypeHash( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

UINT32 Reflection::GetAssemblyHash( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Reflection::GetAssemblies( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

INT8 Reflection::GetAssemblyInfo( CLR_RT_TypedArray_UINT8 param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Reflection::GetTypeFromHash( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Reflection::GetAssemblyFromHash( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UINT8 Reflection::Serialize( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Reflection::Deserialize( CLR_RT_TypedArray_UINT8 param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

