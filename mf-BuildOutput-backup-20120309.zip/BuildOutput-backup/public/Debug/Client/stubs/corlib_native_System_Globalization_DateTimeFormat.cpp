//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Globalization_DateTimeFormat.h"

using namespace System::Globalization;

LPCSTR DateTimeFormat::FormatDigits( INT32 param0, INT32 param1, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

