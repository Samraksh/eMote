//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_net_native.h"
#include "spot_net_native_Microsoft_SPOT_Net_NetworkInformation_NetworkInterface.h"

using namespace Microsoft::SPOT::Net::NetworkInformation;

void NetworkInterface::InitializeNetworkInterfaceSettings( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void NetworkInterface::UpdateConfiguration( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
}

INT32 NetworkInterface::GetNetworkInterfaceCount( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE NetworkInterface::GetNetworkInterface( void param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UINT32 NetworkInterface::IPAddressFromString( LPCSTR param0, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

