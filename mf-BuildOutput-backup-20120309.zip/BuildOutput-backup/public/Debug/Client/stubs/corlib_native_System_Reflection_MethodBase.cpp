//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Reflection_MethodBase.h"

using namespace System::Reflection;

LPCSTR MethodBase::get_Name( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE MethodBase::get_DeclaringType( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

INT8 MethodBase::get_IsPublic( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 MethodBase::get_IsStatic( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 MethodBase::get_IsFinal( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 MethodBase::get_IsVirtual( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 MethodBase::get_IsAbstract( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE MethodBase::Invoke( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

