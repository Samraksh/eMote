//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Threading_WaitHandle.h"

using namespace System::Threading;

INT8 WaitHandle::WaitOne( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT8 param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT32 WaitHandle::WaitMultiple( CLR_RT_TypedArray_UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, UNSUPPORTED_TYPE param2, INT32 param3, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

