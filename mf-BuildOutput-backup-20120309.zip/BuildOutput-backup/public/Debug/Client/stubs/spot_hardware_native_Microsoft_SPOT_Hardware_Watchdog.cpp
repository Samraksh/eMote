//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_native.h"
#include "spot_hardware_native_Microsoft_SPOT_Hardware_Watchdog.h"

using namespace Microsoft::SPOT::Hardware;

INT8 Watchdog::get_Enabled( HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

void Watchdog::set_Enabled( INT8 param0, HRESULT &hr )
{
}

UNSUPPORTED_TYPE Watchdog::get_Timeout( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void Watchdog::set_Timeout( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
}

INT32 Watchdog::get_Behavior( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void Watchdog::set_Behavior( INT32 param0, HRESULT &hr )
{
}

UNSUPPORTED_TYPE Watchdog::get_Log( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void Watchdog::set_Log( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
}

INT8 Watchdog::GetLastOcurrenceDetails( UNSUPPORTED_TYPE * param0, UNSUPPORTED_TYPE param1, UNSUPPORTED_TYPE * param2, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

