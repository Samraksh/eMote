//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_graphics_native.h"
#include "spot_graphics_native_Microsoft_SPOT_Bitmap.h"

using namespace Microsoft::SPOT;

void Bitmap::_ctor( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, HRESULT &hr )
{
}

void Bitmap::_ctor( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, UINT8 param1, HRESULT &hr )
{
}

void Bitmap::Flush( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void Bitmap::Flush( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, HRESULT &hr )
{
}

void Bitmap::Clear( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

INT8 Bitmap::DrawTextInRect( CLR_RT_HeapBlock* pMngObj, LPCSTR * param0, INT32 * param1, INT32 * param2, INT32 param3, INT32 param4, INT32 param5, INT32 param6, UINT32 param7, UINT32 param8, UNSUPPORTED_TYPE param9, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

void Bitmap::SetClippingRectangle( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, HRESULT &hr )
{
}

INT32 Bitmap::get_Width( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Bitmap::get_Height( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void Bitmap::DrawEllipse( CLR_RT_HeapBlock* pMngObj, UINT32 param0, INT32 param1, INT32 param2, INT32 param3, INT32 param4, INT32 param5, UINT32 param6, INT32 param7, INT32 param8, UINT32 param9, INT32 param10, INT32 param11, UINT16 param12, HRESULT &hr )
{
}

void Bitmap::DrawImage( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, UNSUPPORTED_TYPE param2, void param3, INT32 param4, INT32 param5, INT32 param6, INT32 param7, HRESULT &hr )
{
}

void Bitmap::RotateImage( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, UNSUPPORTED_TYPE param3, void param4, INT32 param5, INT32 param6, INT32 param7, INT32 param8, HRESULT &hr )
{
}

void Bitmap::MakeTransparent( CLR_RT_HeapBlock* pMngObj, UINT32 param0, HRESULT &hr )
{
}

void Bitmap::StretchImage( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, UNSUPPORTED_TYPE param2, void param3, INT32 param4, INT32 param5, HRESULT &hr )
{
}

void Bitmap::DrawLine( CLR_RT_HeapBlock* pMngObj, UINT32 param0, INT32 param1, INT32 param2, INT32 param3, INT32 param4, INT32 param5, HRESULT &hr )
{
}

void Bitmap::DrawRectangle( CLR_RT_HeapBlock* pMngObj, UINT32 param0, INT32 param1, INT32 param2, INT32 param3, INT32 param4, INT32 param5, INT32 param6, INT32 param7, UINT32 param8, INT32 param9, INT32 param10, UINT32 param11, INT32 param12, INT32 param13, UINT16 param14, HRESULT &hr )
{
}

void Bitmap::DrawText( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, UNSUPPORTED_TYPE param1, UINT32 param2, UINT32 param3, INT32 param4, HRESULT &hr )
{
}

void Bitmap::SetPixel( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, UINT32 param2, HRESULT &hr )
{
}

UINT32 Bitmap::GetPixel( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

UINT8 Bitmap::GetBitmap( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

void Bitmap::StretchImage( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, UNSUPPORTED_TYPE param4, void param5, INT32 param6, INT32 param7, INT32 param8, INT32 param9, HRESULT &hr )
{
}

void Bitmap::TileImage( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, UNSUPPORTED_TYPE param2, void param3, INT32 param4, INT32 param5, HRESULT &hr )
{
}

void Bitmap::Scale9Image( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, UNSUPPORTED_TYPE param4, void param5, INT32 param6, INT32 param7, INT32 param8, INT32 param9, HRESULT &hr )
{
}

void Bitmap::Dispose( CLR_RT_HeapBlock* pMngObj, INT8 param0, HRESULT &hr )
{
}

