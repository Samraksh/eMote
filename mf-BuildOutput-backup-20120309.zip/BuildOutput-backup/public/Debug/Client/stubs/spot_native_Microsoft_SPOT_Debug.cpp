//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Microsoft_SPOT_Debug.h"

using namespace Microsoft::SPOT;

void Debug::Print( LPCSTR param0, HRESULT &hr )
{
}

UINT32 Debug::GC( INT8 param0, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

