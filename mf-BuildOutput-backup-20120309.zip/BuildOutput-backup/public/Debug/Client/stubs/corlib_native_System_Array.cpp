//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Array.h"

using namespace System;

UNSUPPORTED_TYPE Array::System_Collections_IList_get_Item( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void Array::System_Collections_IList_set_Item( CLR_RT_HeapBlock* pMngObj, INT32 param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
}

INT32 Array::get_Length( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Array::CreateInstance( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void Array::Copy( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, INT32 param2, UNSUPPORTED_TYPE param3, UNSUPPORTED_TYPE param4, HRESULT &hr )
{
}

void Array::Clear( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, INT32 param2, HRESULT &hr )
{
}

INT8 Array::TrySZIndexOf( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, INT32 param2, INT32 param3, UNSUPPORTED_TYPE param4, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

