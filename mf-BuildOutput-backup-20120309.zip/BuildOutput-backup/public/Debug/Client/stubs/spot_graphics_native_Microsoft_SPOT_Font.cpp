//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_graphics_native.h"
#include "spot_graphics_native_Microsoft_SPOT_Font.h"

using namespace Microsoft::SPOT;

INT32 Font::CharWidth( CLR_RT_HeapBlock* pMngObj, CHAR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Font::get_Height( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Font::get_AverageWidth( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Font::get_MaxWidth( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Font::get_Ascent( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Font::get_Descent( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Font::get_InternalLeading( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Font::get_ExternalLeading( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void Font::ComputeExtent( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, INT32 * param1, INT32 * param2, INT32 param3, HRESULT &hr )
{
}

void Font::ComputeTextInRect( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, INT32 * param1, INT32 * param2, INT32 param3, INT32 param4, INT32 param5, INT32 param6, UINT32 param7, HRESULT &hr )
{
}

