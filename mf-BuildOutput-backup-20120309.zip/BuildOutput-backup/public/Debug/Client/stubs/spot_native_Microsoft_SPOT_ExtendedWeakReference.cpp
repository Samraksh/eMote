//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Microsoft_SPOT_ExtendedWeakReference.h"

using namespace Microsoft::SPOT;

void ExtendedWeakReference::_ctor( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, UNSUPPORTED_TYPE param2, UINT32 param3, HRESULT &hr )
{
}

UNSUPPORTED_TYPE ExtendedWeakReference::get_Selector( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UINT32 ExtendedWeakReference::get_Id( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

UINT32 ExtendedWeakReference::get_Flags( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

INT32 ExtendedWeakReference::get_Priority( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void ExtendedWeakReference::set_Priority( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
}

void ExtendedWeakReference::PushBackIntoRecoverList( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

UNSUPPORTED_TYPE ExtendedWeakReference::Recover( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

