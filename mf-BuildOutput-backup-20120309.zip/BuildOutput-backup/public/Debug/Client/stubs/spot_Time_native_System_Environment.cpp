//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_Time_native.h"
#include "spot_Time_native_System_Environment.h"

using namespace System;

INT32 Environment::get_TickCount( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

