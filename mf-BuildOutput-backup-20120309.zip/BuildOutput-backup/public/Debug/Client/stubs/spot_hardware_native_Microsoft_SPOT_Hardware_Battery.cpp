//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_native.h"
#include "spot_hardware_native_Microsoft_SPOT_Hardware_Battery.h"

using namespace Microsoft::SPOT::Hardware;

INT32 Battery::ReadVoltage( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 Battery::ReadTemperature( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT8 Battery::OnCharger( HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 Battery::IsFullyCharged( HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT32 Battery::StateOfCharge( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT8 Battery::WaitForEvent( INT32 param0, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

