//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Microsoft_SPOT_Hardware_SystemInfo__SystemID.h"

using namespace Microsoft::SPOT::Hardware;

UINT8 SystemInfo_SystemID::get_OEM( HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

UINT8 SystemInfo_SystemID::get_Model( HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

UINT16 SystemInfo_SystemID::get_SKU( HRESULT &hr )
{
    UINT16 retVal = 0; 
    return retVal;
}

