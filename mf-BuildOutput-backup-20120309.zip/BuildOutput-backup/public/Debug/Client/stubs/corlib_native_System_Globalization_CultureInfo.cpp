//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Globalization_CultureInfo.h"

using namespace System::Globalization;

UNSUPPORTED_TYPE CultureInfo::get_CurrentUICultureInternal( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void CultureInfo::set_CurrentUICultureInternal( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
}

