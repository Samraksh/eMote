//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_net_native.h"
#include "spot_net_native_Microsoft_SPOT_Net_NetworkInformation_Wireless80211.h"

using namespace Microsoft::SPOT::Net::NetworkInformation;

void Wireless80211::UpdateConfiguration( UNSUPPORTED_TYPE param0, CHAR param1, HRESULT &hr )
{
}

void Wireless80211::SaveAllConfigurations( HRESULT &hr )
{
}

