//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_native.h"
#include "spot_hardware_native_Microsoft_SPOT_Hardware_SPI.h"

using namespace Microsoft::SPOT::Hardware;

void SPI::InternalWriteRead( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT16 param0, INT32 param1, CLR_RT_TypedArray_UINT16 param2, INT32 param3, HRESULT &hr )
{
}

void SPI::InternalWriteRead( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, CLR_RT_TypedArray_UINT8 param2, INT32 param3, HRESULT &hr )
{
}

