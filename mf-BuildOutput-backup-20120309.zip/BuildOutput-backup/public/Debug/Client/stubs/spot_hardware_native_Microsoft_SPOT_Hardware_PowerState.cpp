//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_native.h"
#include "spot_hardware_native_Microsoft_SPOT_Hardware_PowerState.h"

using namespace Microsoft::SPOT::Hardware;

void PowerState::Reboot( INT8 param0, HRESULT &hr )
{
}

INT8 PowerState::WaitForIdleCPU( INT32 param0, INT32 param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE PowerState::get_MaximumTimeToActive( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void PowerState::set_MaximumTimeToActive( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
}

INT32 PowerState::get_WakeupEvents( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void PowerState::set_WakeupEvents( INT32 param0, HRESULT &hr )
{
}

UNSUPPORTED_TYPE PowerState::get_Uptime( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void PowerState::InternalSleep( UINT8 param0, INT32 param1, HRESULT &hr )
{
}

void PowerState::InternalChangePowerLevel( UINT8 param0, HRESULT &hr )
{
}

