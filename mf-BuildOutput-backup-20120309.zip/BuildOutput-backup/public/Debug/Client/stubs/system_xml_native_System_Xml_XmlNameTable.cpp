//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "system_xml_native.h"
#include "system_xml_native_System_Xml_XmlNameTable.h"

using namespace System::Xml;

LPCSTR XmlNameTable::Get( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR XmlNameTable::Add( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

