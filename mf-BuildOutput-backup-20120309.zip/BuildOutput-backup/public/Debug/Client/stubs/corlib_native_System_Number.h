//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#ifndef _CORLIB_NATIVE_SYSTEM_NUMBER_H_
#define _CORLIB_NATIVE_SYSTEM_NUMBER_H_

namespace System
{
    struct Number
    {
        // Helper Functions to access fields of managed object
        // Declaration of stubs. These functions are implemented by Interop code developers
        static LPCSTR FormatNative( UNSUPPORTED_TYPE param0, CHAR param1, INT32 param2, HRESULT &hr );
    };
}
#endif  //_CORLIB_NATIVE_SYSTEM_NUMBER_H_
