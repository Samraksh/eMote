//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_TimeSpan.h"

using namespace System;

INT8 TimeSpan::Equals( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

LPCSTR TimeSpan::ToString( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

void TimeSpan::_ctor( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
}

void TimeSpan::_ctor( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, HRESULT &hr )
{
}

void TimeSpan::_ctor( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, INT32 param4, HRESULT &hr )
{
}

INT32 TimeSpan::CompareTo( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 TimeSpan::Compare( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT8 TimeSpan::Equals( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

