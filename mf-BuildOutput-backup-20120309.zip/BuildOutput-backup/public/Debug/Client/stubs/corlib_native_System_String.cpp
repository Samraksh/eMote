//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_String.h"

using namespace System;

CHAR String::get_Chars( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
    CHAR retVal = 0; 
    return retVal;
}

CHAR String::ToCharArray( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    CHAR retVal = 0; 
    return retVal;
}

CHAR String::ToCharArray( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, HRESULT &hr )
{
    CHAR retVal = 0; 
    return retVal;
}

INT32 String::get_Length( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

LPCSTR String::Split( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Split( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, INT32 param1, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Substring( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Substring( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Trim( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::TrimStart( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::TrimEnd( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

void String::_ctor( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, INT32 param1, INT32 param2, HRESULT &hr )
{
}

void String::_ctor( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, HRESULT &hr )
{
}

void String::_ctor( CLR_RT_HeapBlock* pMngObj, CHAR param0, INT32 param1, HRESULT &hr )
{
}

INT32 String::CompareTo( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::CompareTo( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOf( CLR_RT_HeapBlock* pMngObj, CHAR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOf( CLR_RT_HeapBlock* pMngObj, CHAR param0, INT32 param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOf( CLR_RT_HeapBlock* pMngObj, CHAR param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOfAny( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOfAny( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, INT32 param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOfAny( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOf( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOf( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, INT32 param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::IndexOf( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOf( CLR_RT_HeapBlock* pMngObj, CHAR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOf( CLR_RT_HeapBlock* pMngObj, CHAR param0, INT32 param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOf( CLR_RT_HeapBlock* pMngObj, CHAR param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOfAny( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOfAny( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, INT32 param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOfAny( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_CHAR param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOf( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOf( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, INT32 param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 String::LastIndexOf( CLR_RT_HeapBlock* pMngObj, LPCSTR param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

LPCSTR String::ToLower( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::ToUpper( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Trim( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

INT8 String::Equals( LPCSTR param0, LPCSTR param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 String::op_Equality( LPCSTR param0, LPCSTR param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 String::op_Inequality( LPCSTR param0, LPCSTR param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT32 String::Compare( LPCSTR param0, LPCSTR param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

LPCSTR String::Concat( LPCSTR param0, LPCSTR param1, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Concat( LPCSTR param0, LPCSTR param1, LPCSTR param2, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Concat( LPCSTR param0, LPCSTR param1, LPCSTR param2, LPCSTR param3, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

LPCSTR String::Concat( CLR_RT_TypedArray_LPCSTR param0, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

