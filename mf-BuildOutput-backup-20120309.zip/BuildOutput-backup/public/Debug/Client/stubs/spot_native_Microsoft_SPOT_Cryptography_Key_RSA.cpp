//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Microsoft_SPOT_Cryptography_Key_RSA.h"

using namespace Microsoft::SPOT::Cryptography;

UINT8 Key_RSA::Encrypt( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, CLR_RT_TypedArray_UINT8 param3, HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

UINT8 Key_RSA::Decrypt( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, CLR_RT_TypedArray_UINT8 param3, HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

INT8 Key_RSA::VerifySignature( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, CLR_RT_TypedArray_UINT8 param3, INT32 param4, INT32 param5, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

