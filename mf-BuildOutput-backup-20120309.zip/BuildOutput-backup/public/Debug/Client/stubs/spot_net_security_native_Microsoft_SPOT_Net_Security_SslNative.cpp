//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_net_security_native.h"
#include "spot_net_security_native_Microsoft_SPOT_Net_Security_SslNative.h"

using namespace Microsoft::SPOT::Net::Security;

INT32 SslNative::SecureServerInit( INT32 param0, INT32 param1, UNSUPPORTED_TYPE param2, double param3, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SslNative::SecureClientInit( INT32 param0, INT32 param1, UNSUPPORTED_TYPE param2, double param3, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SslNative::UpdateCertificates( INT32 param0, UNSUPPORTED_TYPE param1, double param2, HRESULT &hr )
{
}

void SslNative::SecureAccept( INT32 param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
}

void SslNative::SecureConnect( INT32 param0, LPCSTR param1, UNSUPPORTED_TYPE param2, HRESULT &hr )
{
}

INT32 SslNative::SecureRead( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, INT32 param2, INT32 param3, INT32 param4, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SslNative::SecureWrite( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, INT32 param2, INT32 param3, INT32 param4, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SslNative::SecureCloseSocket( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SslNative::ExitSecureContext( INT32 param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SslNative::ParseCertificate( CLR_RT_TypedArray_UINT8 param0, LPCSTR param1, LPCSTR * param2, LPCSTR * param3, UNSUPPORTED_TYPE * param4, float param5, HRESULT &hr )
{
}

INT32 SslNative::DataAvailable( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

