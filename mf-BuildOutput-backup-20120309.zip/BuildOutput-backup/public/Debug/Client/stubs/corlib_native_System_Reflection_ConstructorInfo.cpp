//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Reflection_ConstructorInfo.h"

using namespace System::Reflection;

UNSUPPORTED_TYPE ConstructorInfo::Invoke( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

