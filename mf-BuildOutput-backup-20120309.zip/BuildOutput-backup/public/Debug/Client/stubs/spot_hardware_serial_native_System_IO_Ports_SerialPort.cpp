//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_serial_native.h"
#include "spot_hardware_serial_native_System_IO_Ports_SerialPort.h"

using namespace System::IO::Ports;

void SerialPort::InternalOpen( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void SerialPort::InternalClose( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

INT32 SerialPort::Read( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SerialPort::Write( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SerialPort::InternalDispose( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

void SerialPort::Flush( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
}

INT32 SerialPort::BytesInBuffer( CLR_RT_HeapBlock* pMngObj, INT8 param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SerialPort::DiscardBuffer( CLR_RT_HeapBlock* pMngObj, INT8 param0, HRESULT &hr )
{
}

