//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Reflection_Assembly.h"

using namespace System::Reflection;

LPCSTR Assembly::get_FullName( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Assembly::GetType( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Assembly::GetTypes( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void Assembly::GetVersion( CLR_RT_HeapBlock* pMngObj, INT32 * param0, INT32 * param1, INT32 * param2, INT32 * param3, HRESULT &hr )
{
}

LPCSTR Assembly::GetManifestResourceNames( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    LPCSTR retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Assembly::GetExecutingAssembly( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Assembly::LoadInternal( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, LPCSTR param2, INT8 param3, INT32 param4, INT32 param5, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE Assembly::Load( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

