//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_hardware_usb_native.h"
#include "spot_hardware_usb_native_Microsoft_SPOT_Hardware_UsbClient_UsbController.h"

using namespace Microsoft::SPOT::Hardware::UsbClient;

INT32 UsbController::get_Status( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE UsbController::get_Configuration( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void UsbController::set_Configuration( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, HRESULT &hr )
{
}

INT8 UsbController::nativeStart( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 UsbController::nativeStop( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT32 UsbController::get_Count( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

