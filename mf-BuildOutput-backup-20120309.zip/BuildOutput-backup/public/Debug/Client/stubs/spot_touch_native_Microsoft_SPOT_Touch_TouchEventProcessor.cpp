//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_touch_native.h"
#include "spot_touch_native_Microsoft_SPOT_Touch_TouchEventProcessor.h"

using namespace Microsoft::SPOT::Touch;

UNSUPPORTED_TYPE TouchEventProcessor::ProcessEvent( CLR_RT_HeapBlock* pMngObj, UNSUPPORTED_TYPE param0, UINT32 param1, UINT32 param2, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

