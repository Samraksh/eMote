//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "corlib_native.h"
#include "corlib_native_System_Resources_ResourceManager.h"

using namespace System::Resources;

UNSUPPORTED_TYPE ResourceManager::GetObjectInternal( CLR_RT_HeapBlock* pMngObj, INT16 param0, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

INT32 ResourceManager::FindResource( LPCSTR param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

UNSUPPORTED_TYPE ResourceManager::GetObject( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

