//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Microsoft_SPOT_Hardware_Utility.h"

using namespace Microsoft::SPOT::Hardware;

UINT32 Utility::ComputeCRC( CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, UINT32 param3, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

UINT32 Utility::ExtractValueFromArray( CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

void Utility::InsertValueIntoArray( CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, UINT32 param3, HRESULT &hr )
{
}

UINT8 Utility::ExtractRangeFromArray( CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

UINT8 Utility::CombineArrays( CLR_RT_TypedArray_UINT8 param0, CLR_RT_TypedArray_UINT8 param1, HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

UINT8 Utility::CombineArrays( CLR_RT_TypedArray_UINT8 param0, INT32 param1, INT32 param2, CLR_RT_TypedArray_UINT8 param3, INT32 param4, INT32 param5, HRESULT &hr )
{
    UINT8 retVal = 0; 
    return retVal;
}

void Utility::SetLocalTime( INT32 param0, HRESULT &hr )
{
}

UNSUPPORTED_TYPE Utility::GetMachineTime( HRESULT &hr )
{
    UNSUPPORTED_TYPE retVal = 0; 
    return retVal;
}

void Utility::Piezo( UINT32 param0, UINT32 param1, HRESULT &hr )
{
}

void Utility::Backlight( INT8 param0, HRESULT &hr )
{
}

