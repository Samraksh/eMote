//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#ifndef _CORLIB_NATIVE_SYSTEM_MULTICASTDELEGATE_H_
#define _CORLIB_NATIVE_SYSTEM_MULTICASTDELEGATE_H_

namespace System
{
    struct MulticastDelegate
    {
        // Helper Functions to access fields of managed object
        // Declaration of stubs. These functions are implemented by Interop code developers
        static INT8 op_Equality( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr );
        static INT8 op_Inequality( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE param1, HRESULT &hr );
    };
}
#endif  //_CORLIB_NATIVE_SYSTEM_MULTICASTDELEGATE_H_
