//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_io_native.h"
#include "spot_io_native_Microsoft_SPOT_IO_NativeIO.h"

using namespace Microsoft::SPOT::IO;

void NativeIO::Format( LPCSTR param0, LPCSTR param1, UINT32 param2, HRESULT &hr )
{
}

void NativeIO::Delete( LPCSTR param0, HRESULT &hr )
{
}

INT8 NativeIO::Move( LPCSTR param0, LPCSTR param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

void NativeIO::CreateDirectory( LPCSTR param0, HRESULT &hr )
{
}

UINT32 NativeIO::GetAttributes( LPCSTR param0, HRESULT &hr )
{
    UINT32 retVal = 0; 
    return retVal;
}

void NativeIO::SetAttributes( LPCSTR param0, UINT32 param1, HRESULT &hr )
{
}

