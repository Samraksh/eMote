//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_net_native.h"
#include "spot_net_native_Microsoft_SPOT_Net_SocketNative.h"

using namespace Microsoft::SPOT::Net;

INT32 SocketNative::socket( INT32 param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SocketNative::bind( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, HRESULT &hr )
{
}

void SocketNative::connect( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, INT8 param2, HRESULT &hr )
{
}

INT32 SocketNative::send( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, INT32 param2, INT32 param3, INT32 param4, INT32 param5, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SocketNative::recv( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, INT32 param2, INT32 param3, INT32 param4, INT32 param5, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SocketNative::close( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SocketNative::listen( UNSUPPORTED_TYPE param0, INT32 param1, HRESULT &hr )
{
}

INT32 SocketNative::accept( UNSUPPORTED_TYPE param0, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SocketNative::getaddrinfo( LPCSTR param0, LPCSTR * param1, UNSUPPORTED_TYPE * param2, HRESULT &hr )
{
}

void SocketNative::shutdown( UNSUPPORTED_TYPE param0, INT32 param1, INT32 * param2, HRESULT &hr )
{
}

INT32 SocketNative::sendto( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, INT32 param2, INT32 param3, INT32 param4, INT32 param5, CLR_RT_TypedArray_UINT8 param6, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SocketNative::recvfrom( UNSUPPORTED_TYPE param0, CLR_RT_TypedArray_UINT8 param1, INT32 param2, INT32 param3, INT32 param4, INT32 param5, UNSUPPORTED_TYPE * param6, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

void SocketNative::getpeername( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE * param1, HRESULT &hr )
{
}

void SocketNative::getsockname( UNSUPPORTED_TYPE param0, UNSUPPORTED_TYPE * param1, HRESULT &hr )
{
}

void SocketNative::getsockopt( UNSUPPORTED_TYPE param0, INT32 param1, INT32 param2, CLR_RT_TypedArray_UINT8 param3, HRESULT &hr )
{
}

void SocketNative::setsockopt( UNSUPPORTED_TYPE param0, INT32 param1, INT32 param2, CLR_RT_TypedArray_UINT8 param3, HRESULT &hr )
{
}

INT8 SocketNative::poll( UNSUPPORTED_TYPE param0, INT32 param1, INT32 param2, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

void SocketNative::ioctl( UNSUPPORTED_TYPE param0, UINT32 param1, UINT32 * param2, HRESULT &hr )
{
}

