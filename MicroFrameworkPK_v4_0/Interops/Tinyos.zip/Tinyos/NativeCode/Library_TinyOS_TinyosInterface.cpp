//-----------------------------------------------------------------------------
//
//                   ** WARNING! **
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "Library.h"
#include "Library_TinyOS_TinyosInterface.h"
#include <rcc/stm32f10x_rcc.h>


typedef uint8_t error_t  ;
extern int main_tinyos();
//extern error_t RealMainP__PlatformInit__init(void);
//extern void RealMainP__Scheduler__taskLoop(void);
//extern void RealMainP__Boot__booted(void);
//extern error_t RealMainP__SoftwareInit__init(void);
//extern void RealMainP__Scheduler__init(void);
//extern bool RealMainP__Scheduler__runNextTask(void);
//extern void printSchedulerContents();

int globalCheck = 0;

using namespace TinyOS;



void TinyosInterface::execute( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT8 param0, HRESULT &hr )
{
	hal_printf("About to enter tinyos\n");

//	uint8_t sys_clk = RCC_GetSYSCLKSource();
	main_tinyos();

	
	//if(globalCheck == 0)
	//{
	//	RealMainP__Scheduler__init();

	//	hal_printf("Initializing Platform\n");
	//	RealMainP__PlatformInit__init();

	//	while (RealMainP__Scheduler__runNextTask()) ;
	//	printSchedulerContents();

	//	RealMainP__SoftwareInit__init();
	//	while (RealMainP__Scheduler__runNextTask()) ;
	//	printSchedulerContents();

	//	globalCheck++;
	//}

//	RealMainP__Boot__booted();

//	RealMainP__Scheduler__taskLoop();

	// Nived : Calling main in tinyos
	

}

