////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Microsoft Corporation.  All rights reserved.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "Timers.h"
#include "C:\MicroFrameworkPK_v4_0\Solutions\STM32F10x\DeviceCode\drivers\tim\netmf_timers.h"

//---//

int testCount = 0;

void ISR_TIMER_4( void* Param );

Timers::Timers( UINT32 DisplayIntervalSeconds, UINT32 TimerDurationSeconds )
{
	// Initializes the gpio pins
	CPU_GPIO_Initialize();
};

BOOL Timers::Execute( LOG_STREAM Stream )
{
	hal_printf("Timer Test Begin \n");

	// Indicates the start of the test
	CPU_GPIO_EnableOutputPin(1,TRUE);

	// Configure Pin 2 as the pin of interest
	CPU_GPIO_EnableOutputPin(2,FALSE);

	// Initialize Hal Level Time Driver
	if (!Timer_Driver :: Initialize (4, TRUE, 0, 0, ISR_TIMER_4, NULL))
		{
			return FALSE;
		}

	// Sets compare value to 1000 count values
	Timer_Driver::SetCompare( 4, 1000 );

	while(testCount < 1000)
	{

	}

	// Indicates the end of the test
	CPU_GPIO_SetPinState(1, FALSE);

}; //Execute

void ISR_TIMER_4( void* Param )
{
	if (TIM_GetITStatus(TIM2, TIM_IT_CC1) != RESET)
	  {
	    TIM_ClearITPendingBit(TIM2, TIM_IT_CC1 );
	  }

	if(testCount % 2 == 0)
		CPU_GPIO_SetPinState(2, TRUE);
	else
		CPU_GPIO_SetPinState(2,FALSE);
	testCount++;

}

//--//

