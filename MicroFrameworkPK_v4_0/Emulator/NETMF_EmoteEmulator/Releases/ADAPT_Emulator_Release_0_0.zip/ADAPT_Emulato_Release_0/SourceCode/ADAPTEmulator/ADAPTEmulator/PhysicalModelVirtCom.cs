﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ADAPTEmulator
{
    enum VirtEmulatorInterface
    {
        USART, SPI, I2C, USB,
    } ;

    class PhysicalModelVirtCom
    {
        int serverPort = 47000; //default port
        Thread clientThread;
        Socket clientSocket;
        static TcpListener myListener;

        /*public PhysicalModelVirtCom()
        {
            clientThread = new Thread(new ThreadStart(HandleClients));
        }
        public PhysicalModelVirtCom(int port)
        {
            serverPort = port;
            this.PhysicalModelVirtCom();
        }*/
                        
        public void StartVirtComServer()
        {

            try
            {
                //IPAddress ipAd = IPAddress.Parse("localhost");
                IPAddress ipAd = IPAddress.Loopback;
                // use local m/c IP address, and 
                // use the same in the client

                /* Initializes the Listener */
                myListener = new TcpListener(ipAd, serverPort);

                /* Start Listeneting at the specified port */
                myListener.Start();

                Console.WriteLine("The server is running at port: " + serverPort.ToString() + "...");
                Console.WriteLine("The local End point is  :" + myListener.LocalEndpoint);
                
                Console.WriteLine("Starting thread to accept connections.....");
                clientThread = new Thread(new ThreadStart(HandleClients));
                clientThread.Start();
                
            }
            catch (Exception e)
            {
                Console.WriteLine("Error..... " + e.StackTrace);
            }

        }
        
        void HandleClients()
        {
           // while (true)
            //{
                Console.WriteLine("Waiting for connection...");
                try
                {
                    clientSocket = myListener.AcceptSocket();
                    Console.WriteLine("Connection accepted from " + clientSocket.RemoteEndPoint);

                    byte[] b = new byte[100];
                    int k = clientSocket.Receive(b);
                    Console.WriteLine("Recieved...");
                    for (int i = 0; i < k; i++)
                        Console.Write(Convert.ToChar(b[i]));

                    ASCIIEncoding asen = new ASCIIEncoding();
                    clientSocket.Send(asen.GetBytes("The string was recieved by the server."));
                    Console.WriteLine("\nSent Acknowledgement");
                    
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error..... " + e.StackTrace);
                }





            //}
            
        }
        public int SendModelMessage(byte[] mesg)
        {
            return clientSocket.Send(mesg);
        }

        public void StopVirtComServer()
        {
            myListener.Stop();
        }
    }
}
