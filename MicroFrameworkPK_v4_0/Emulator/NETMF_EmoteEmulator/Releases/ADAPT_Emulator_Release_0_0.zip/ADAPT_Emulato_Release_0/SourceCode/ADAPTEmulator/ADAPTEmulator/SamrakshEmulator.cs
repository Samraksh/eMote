﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;
using System.Windows;

using Microsoft.SPOT.Emulator;
using Microsoft.SPOT.Emulator.Gpio;
using Microsoft.SPOT.Emulator.Com;


//using Microsoft.SPOT.Emulator.Serial;
using ADAPTEmulator;

namespace ADAPTEmulator
{
    class SamrakshEmulator : Emulator
    {
        public override void SetupComponent()
        {
            Microsoft.SPOT.Emulator.Sample.EmulatorSerialPort esp = new Microsoft.SPOT.Emulator.Sample.EmulatorSerialPort();
            esp.ComponentId = "COM1";
            esp.ComPortHandle = new ComPortHandle(TransportType.Usart, 1);
                        
            this.GpioPorts.MaxPorts = 128; //Emote has 8 GPIO pins exposed
            GpioPort[] gpio = new GpioPort[14]; //create 6+8 ports
            /*gpio[0] = new GpioPort();
            gpio[1] = new GpioPort();
            gpio[2] = new GpioPort();
            gpio[3] = new GpioPort();
            gpio[4] = new GpioPort();
            gpio[5] = new GpioPort();
            gpio[6] = new GpioPort();
            gpio[7] = new GpioPort();
            gpio[8] = new GpioPort();
            gpio[9] = new GpioPort();
            gpio[10] = new GpioPort();
            gpio[11] = new GpioPort();
            gpio[12] = new GpioPort();
            gpio[13] = new GpioPort();*/

            for (int i = 0; i < 14; i++)
                gpio[i] = new GpioPort();

            //Virtual Led pins
            gpio[0].ComponentId = "led_0";
            gpio[1].ComponentId = "led_1";
            gpio[2].ComponentId = "led_2";

            //Virtual Led pins
            gpio[3].ComponentId = "button_0";
            gpio[4].ComponentId = "button_1";
            gpio[5].ComponentId = "button_2";


            for (int i = 0; i < 8; i++)
            {
                //gpio[i] = new GpioPort();
                string compId = "gpio_" + i.ToString();
                gpio[i+6].ComponentId = compId; //name them
            }
               
            //Configure pins as input or output and
            //Map exposed pins to the chip pins from hardware
            for (int i = 0; i < 14; i++)
            {
                gpio[i].Pin = (Microsoft.SPOT.Hardware.Cpu.Pin)i;
                gpio[i].ModesAllowed = GpioPortMode.InputOutputPort;
                gpio[i].ModesExpected = GpioPortMode.InputOutputPort;
            }

            //Register them with the emulator
            for (int i = 0; i < 14; i++)
            {
                this.RegisterComponent(gpio[i]);  
            }
          
            //register Emulator Serial Port
            this.RegisterComponent(esp);
            base.SetupComponent();
        }

        public override void InitializeComponent()
        {
            base.InitializeComponent();

            // Start the UI in its own thread.
            Thread uiThread = new Thread(StartForm);
            uiThread.SetApartmentState(ApartmentState.STA);
            uiThread.IsBackground = true;
            uiThread.Start();
        }

        public override void UninitializeComponent()
        {
            base.UninitializeComponent();

            // The emulator is stopped. Close the WinForm UI.
            System.Windows.Forms.Application.Exit();
        }          

        private void StartForm()
        {
            // Some initial setup for the WinForm UI
            System.Windows.Forms.Application.EnableVisualStyles();
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
            
            // Start the WinForm UI. Run() returns when the form is closed.
            System.Windows.Forms.Application.Run(new Form1(this));
            
            // When the user closes the WinForm UI, stop the emulator.
            Stop();
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        
        [STAThread]   
        static void Main()
        {
            
            SamrakshEmulator p1=new SamrakshEmulator();
            p1.Start();
            
            //Thread.Sleep(Timeout.Infinite);
        }
    }
}
