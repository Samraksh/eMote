Samraksh's Micro Framework Emulator Release 0 Notes
====================================================


Directory Structure:
--------------------
bin - Contains all the binary dlls 
    - includes all dlls needed to run the emulator without installing the porting kit
    - includes a binary of the ADAPT emulator and test applications in the tutorial
    - The RunTest.bat in the bin directory is example batch file for running emulations from command line

DemoVideo - Contains a video of the demo of the two example applications

Documenation - contains a manual detailing the design of the emulator and a tutorial which helps the users through the two example applications

SourceCode - contains the complete source code.
    - ADAPTEmulator: Has the source for the emulator
    - MFApplications: Has the soruce for the two test applications in the tutorial
    - PhysicalModels: Has the source code for the Open Loop Car Model
    - PhyscialModelCommunicationLibrary: Has the code for the PhysicalModelEmulatorComm class written by Samraksh 
	to make the interaction between the model and emulator easy.


Release 0 Feature:
-------------------
- Support for GPIO input automation
- Support for Physical Models (through serial (only) communication) 
- Timers, GPIO, Interrupt, Serial


Future Features:
------------------
Release 1:
- SPI, I2C, ADC

Release 2: 
- Radio, Network Emulation


Support:
Email support@samraksh.com with the subject "Emulator:"