function [X, Y, CarAngle, Velocity, C_x,C_Y] = openLoopCar (SteeringAnlge, Accelaration)

    PrevLoc=[423 613];
    Center=[367.74 764.83]
    RadiusOfTurn=161.567;

    Velocity=50;


    %Determine angular displacement

    %theta = pi/180;
    theta = Velocity/RadiusOfTurn
    figure();
    hold on;
    plot (Center(1),Center(2),'og');
    plot(PrevLoc(1),PrevLoc(2),'ob');
        for i=1:7
        if(i>1)
            PrevLoc(1)=x(i-1);
            PrevLoc(2)=y(i-1);
        end
       
         plot(x(i),y(i),'or');
    end

    axis ([200 550 600 950])
    hold off;

end

function updateLocation (a,c,r)

end

function findNextPointOnSL()

end

function findNextPointOnCircle(a,c,r)
 %Initial angle from y-axis
        alpha = atan2(a(2)-c(2),a(1)-c(1))

        x(i)=c(1)+r* cos(alpha+theta);
        y(i)=c(2)+r* sin(alpha+theta);

end

