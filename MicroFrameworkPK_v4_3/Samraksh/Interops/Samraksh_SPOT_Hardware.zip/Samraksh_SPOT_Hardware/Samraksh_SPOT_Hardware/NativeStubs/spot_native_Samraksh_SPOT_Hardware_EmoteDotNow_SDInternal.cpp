//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Samraksh_SPOT_Hardware_EmoteDotNow_SDInternal.h"

using namespace Samraksh::SPOT::Hardware::EmoteDotNow;

INT32 SDInternal::InternalInitialize( HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SDInternal::InternalWrite( CLR_RT_TypedArray_UINT8 param0, UINT16 param1, UINT16 param2, UINT32 param3, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

INT32 SDInternal::InternalRead( CLR_RT_TypedArray_UINT8 param0, UINT16 param1, UINT16 param2, UINT32 param3, HRESULT &hr )
{
    INT32 retVal = 0; 
    return retVal;
}

