//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "spot_native.h"
#include "spot_native_Samraksh_SPOT_Hardware_EmoteDotNow_EmoteLCD.h"

using namespace Samraksh::SPOT::Hardware::EmoteDotNow;

INT8 EmoteLCD::Initialize( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 EmoteLCD::Uninitialize( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 EmoteLCD::Write( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 EmoteLCD::SetDP( CLR_RT_HeapBlock* pMngObj, INT8 param0, INT8 param1, INT8 param2, INT8 param3, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 EmoteLCD::WriteN( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 EmoteLCD::WriteRawBytes( CLR_RT_HeapBlock* pMngObj, INT32 param0, INT32 param1, INT32 param2, INT32 param3, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 EmoteLCD::Blink( CLR_RT_HeapBlock* pMngObj, INT32 param0, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

INT8 EmoteLCD::Clear( CLR_RT_HeapBlock* pMngObj, HRESULT &hr )
{
    INT8 retVal = 0; 
    return retVal;
}

